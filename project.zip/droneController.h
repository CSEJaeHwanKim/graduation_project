#ifndef DRONECONTROLLER_H
#define DRONECONTROLLER_H

#include <utility>
#include <mutex>
#include <iostream>
#include <wiringPi.h>
#include <string>
#include "singleton.hpp"
 

namespace droneControlType {
	enum Enum {
		throttle, pitch, roll, yaw
	};
}
namespace dronePWM {
	enum Enum {
		current, neutral, min, max, min2neu, neu2max
	};
}

namespace commandType{
	enum Enum {
		stop,turnOn,takeOff,landing,move,pause,skip
	};
}

class droneController :public singleton<droneController> {
private:
	short PWM[4][6];
	float pwm_percentage[4];
	bool is_permit;
	mutex mutex_throttle, mutex_roll, mutex_pitch, mutex_yaw;
private:
	/*template<typename type>
	type constrain(type value, type min, type max);
	*/
	double constrain(double percent);
	short map(float percent, droneControlType::Enum controlType);
	void pwm_gap_calc();
public:
	droneController();

	void set_throttle(float percent);
	//back < 50(neutral) < front
	void set_pitch(float percent);
	//left < 50(neutral) < right
	void set_roll(float percent);
	void set_yaw(float percent);

	void set_throttle_fluctuation(float rate_of_change);
	void set_pitch_fluctuation(float rate_of_change);
	void set_roll_fluctuation(float rate_of_change);
	void set_yaw_fluctuation(float rate_of_change);
	
	float get_pwm_percentage(droneControlType::Enum controlType);
	short get_pwm(droneControlType::Enum controlType);
	string get_pwm_string();
public:
	void start();
	void stop_drone();

};




#endif
/*
template<typename type>
inline type droneController::constrain(type value, type min, type max)
{
	if (value > max) return max;
	else if (value < min) return min;
	else return value;
}
*/