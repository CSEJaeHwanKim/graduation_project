#include <iostream>
//#include <Windows.h>

#include <unistd.h>  
#include "AirpressClass.h"

int main() {
	AirpressClass *t = AirpressClass::getInstance();
	t->start();

	while( true ) {
		cout << "pressure = " <<  t->getPressure() << endl;
		cout << "temperature = " << t->getTemperature() << endl;
		cout << "altitude = " << t->getAltitude() << endl;
		cout << "hPa based on feet = " << t->getHpaOnFoot() << endl;
		cout << "density altitude = " << t->getDensityAltitude() << "\n\n";
		usleep(100000);
	}
	
	return 1;
}