#ifndef SONIC_H
#define SONIC_H
/*
sensor : HC - SR04
frequency : 4kHz
angle : < 15 degree
Confidence Intervals : 2cm ~ 300cm

*/
#include <wiringPi.h>
#include <stdio.h>
#include <stdlib.h>
#include <thread>
#include <mutex>
#include <iostream>
#include "singleton.hpp"

using namespace std;

class UltrasonicClass:public singleton<UltrasonicClass> {
private:
	 int trig, echo;
	 float distance, velocity, acceleration;
	 bool is_measuring;
private:
	void starter();
	void measure_distance();
public:
	UltrasonicClass();
	~UltrasonicClass();
	UltrasonicClass(int trig, int echo);
	
	float getDistance();
	float getVelocity();
	float getAcceleration();
	void start();

};


#endif        /* SONIC_H */