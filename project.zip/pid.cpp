#include "pid.h"

PID::PID(double Kp, double Ki, double Kd, double min, double max, double dt) {
	this->_Kp = Kp;
	this->_Ki = Ki;
	this->_Kd = Kd;
	this->_min = min;
	this->_max = max;
	this->_dt = dt;
	this->_pre_error = 0;
	this->_integral = 0;
}

double PID::calculate(double setpoint, double current)
{

	double error = setpoint - current;

	double Pout = _Kp * error;

	_integral += error * _dt;
	double Iout = _Ki * _integral;

	double derivative = (error - _pre_error) / _dt;
	double Dout = _Kd * derivative;

	double output = Pout + Iout + Dout;

	if (output > _max){ output = _max; }
	else if (output < _min){ output = _min; }
		
	_pre_error = error;

	return output;
}

double PID::calculate(double setpoint, double current, double dt)
{
	double error = setpoint - current;

	double Pout = _Kp * error;

	_integral += error * dt;
	double Iout = _Ki * _integral;

	double derivative = (error - _pre_error) / dt;
	double Dout = _Kd * derivative;

	double output = Pout + Iout + Dout;

	if (output > _max) { output = _max; }
	else if (output < _min) { output = _min; }

	_pre_error = error;

	return output;
}

void PID::setGain(double Kp, double Ki, double Kd)
{
	this->_Kp = Kp;
	this->_Ki = Ki;
	this->_Kd = Kd;
}

void PID::set_dt(double dt)
{
	this->_dt = dt;
}

void PID::init_param()
{
	this->_pre_error = 0;
	this->_integral = 0;
}


PID::~PID()
{
}
