#include "ultrasonic.h"
#include "filters.h"
//#include <Windows.h>

#define ULTRASONIC_DEBUG_OUTPUT

#ifdef ULTRASONIC_DEBUG_OUTPUT
#include <fstream>
#endif

UltrasonicClass::UltrasonicClass() {
	this->echo = 24;	// 24
	this->trig = 23;	// 23
	this->is_measuring = false;
	this->distance = 5;
	this->acceleration = 0;
	this->velocity = 0;
}
UltrasonicClass::UltrasonicClass(int trig, int echo) {
	this->echo = echo;
	this->trig = trig;
	this->is_measuring = false;
}
UltrasonicClass::~UltrasonicClass() {


}
void UltrasonicClass::start() {
	wiringPiSetup();

	if (!this->is_measuring) {
		thread tt([&]() { starter(); });
		// tt.join();
		tt.detach();
	}
	
}

void UltrasonicClass::starter()
{
	char buffer_size = 10;
	float buffer[10] = { 0,1,2,3,4 };
	int index = 0;
	bool stop_flag = false;
	while (true) {
		if (!this->is_measuring) {
			thread tt([&]() { measure_distance(); });
			// tt.join();
			tt.detach();
			delay(1000);
		}
		buffer[index++] = this->distance;
		if (index >= buffer_size) {
			index = 0;
		}
		stop_flag = true;
		for (int i = 1; i < buffer_size; i++) {
			if (buffer[0] != buffer[i]) { stop_flag = false; break; }
		}
		if (stop_flag) {
			stop_flag = false;
			is_measuring = false;

		}

		delay(10);
	}
}

void UltrasonicClass::measure_distance() {
#ifdef ULTRASONIC_DEBUG_OUTPUT
		ofstream debug_output;
		debug_output.open("ultrasonic.txt");
		debug_output << "law value\tkalman value" << endl;
		//debug_output << "law value\tkalman value\nvelocity\tvelocity kalman\tacc" << endl;
#endif
	this->is_measuring = true;


	int start_time, end_time, travel_time ,prev_m_time=0, time_gap;
	float prev_velocity = 0;
	float prev_distance = 0;
	float temp_distance,temp_velocity,temp_acceleration;
	float raw_value = 0;
	int acc_limit = 3;
	float maf_temp = 0;
	simpleKfilter distance_kfilter, variation_kfilter, tempKfilter;
	LPF distanceLPF(0.1, 0.01);
	MAF velocityMAF(0.0, 10U), distanceMAF(distance, 60U);

	
	


	printf("measure_distance start\n");
	pinMode(trig, OUTPUT);
	pinMode(echo, INPUT);
	digitalWrite(trig, LOW);
	try
	{
		while (is_measuring) {
			digitalWrite(trig, HIGH);
			delayMicroseconds(100);
			digitalWrite(trig, LOW);
			while (digitalRead(echo) == 0);
			start_time = micros();
			while (digitalRead(echo) == 1);
			end_time = micros();
			travel_time = (end_time - start_time);
			//travel_time  = 

			//micro 70�� ������ 0���� �ʱ�ȭ��.
			//17400  = 300cm
			if (travel_time < 0 || travel_time > 17400) {continue;}
			raw_value = (travel_time / 58.);

			time_gap = end_time - prev_m_time;
			maf_temp = distanceMAF.nonsave_step(raw_value);
			temp_distance = distance_kfilter.step(distanceLPF.step(maf_temp)); //distance
			//temp_distance = distanceMAF.nonsave_step(raw_value); //distance
			temp_velocity = velocityMAF.step((temp_distance - prev_distance) * (10000.0 / time_gap)); //velocity
			temp_acceleration = (temp_velocity - prev_velocity) * (10000.0 / time_gap); //acceleration
			//cout << temp_distance <<", "<< (travel_time / 58.) << ", " << travel_time << endl;
			if (temp_acceleration < acc_limit && temp_acceleration > -acc_limit)
			{
				this->distance = temp_distance;
				distanceMAF.save_value(raw_value, maf_temp);
				//this->distance = distance_kfilter.step(distanceLPF.step((travel_time / 29. / 2.)));
				// 1000000 / travel_time <- cm/s , 10000 / travel_time <- m/s
				this->velocity = temp_velocity;
				this->acceleration = (this->velocity - prev_velocity) * (10000.0 / travel_time);
			}
#ifdef ULTRASONIC_DEBUG_OUTPUT
			debug_output << raw_value << ",";
			debug_output << velocity << ",";
			debug_output << this->distance << endl;
			//debug_output << (this->distance - prev_distance) * (10000.0 / travel_time) << "\t";
			//debug_output << this->velocity << "\t";
			//debug_output << this->acceleration << endl;
#endif
			//printf("distance : %.2lf , velocity : %.2lfm/s , acc : %.2lfm/s \n", distance, velocity, acceleration);
			//printf("%.2lf %.2lf\n", this->distance, prev_distance);
			if (temp_acceleration < acc_limit && temp_acceleration > -acc_limit)
			{
				prev_velocity = this->velocity;
				prev_distance = this->distance;
				prev_m_time = start_time;
			}
			delayMicroseconds(100);
		}
	}
	catch (const std::exception&)
	{
		this->is_measuring = false;
	}
	

	this->is_measuring = false;
}



float UltrasonicClass::getDistance() {

	return this->distance;
}

float UltrasonicClass::getVelocity()
{
	return this->velocity;
}

float UltrasonicClass::getAcceleration()
{
	return this->acceleration;
}

