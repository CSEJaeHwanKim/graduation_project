#include "droneController.h"

using namespace std;

// 기본 세팅
droneController::droneController() {
	PWM[droneControlType::throttle][dronePWM::current] = PWM[droneControlType::throttle][dronePWM::min] = 1083;
	PWM[droneControlType::throttle][dronePWM::neutral] = 1098;
	PWM[droneControlType::throttle][dronePWM::max] = 1874;
	

	PWM[droneControlType::pitch][dronePWM::current] = PWM[droneControlType::pitch][dronePWM::neutral] = 1484;
	PWM[droneControlType::pitch][dronePWM::min] = 1083;
	PWM[droneControlType::pitch][dronePWM::max] = 1873;

	PWM[droneControlType::roll][dronePWM::current] = PWM[droneControlType::roll][dronePWM::neutral] = 1477;
	PWM[droneControlType::roll][dronePWM::min] = 1084;
	PWM[droneControlType::roll][dronePWM::max] = 1874;

	PWM[droneControlType::yaw][dronePWM::current] = PWM[droneControlType::yaw][dronePWM::neutral] = 1470;
	PWM[droneControlType::yaw][dronePWM::min] = 1083;
	PWM[droneControlType::yaw][dronePWM::max] = 1878;

	pwm_percentage[droneControlType::throttle] = 0;
	pwm_percentage[droneControlType::pitch] = 50;
	pwm_percentage[droneControlType::roll] = 50;
	pwm_percentage[droneControlType::yaw] = 50;

	pwm_gap_calc();
	is_permit = false;
}
void droneController::pwm_gap_calc()
{

	PWM[droneControlType::throttle][dronePWM::min2neu] = PWM[droneControlType::throttle][dronePWM::neutral] - PWM[droneControlType::throttle][dronePWM::min];
	PWM[droneControlType::throttle][dronePWM::neu2max] = PWM[droneControlType::throttle][dronePWM::max] - PWM[droneControlType::throttle][dronePWM::neutral];

	PWM[droneControlType::pitch][dronePWM::min2neu] = PWM[droneControlType::pitch][dronePWM::neutral] - PWM[droneControlType::pitch][dronePWM::min];
	PWM[droneControlType::pitch][dronePWM::neu2max] = PWM[droneControlType::pitch][dronePWM::max] - PWM[droneControlType::pitch][dronePWM::neutral];

	PWM[droneControlType::roll][dronePWM::min2neu] = PWM[droneControlType::roll][dronePWM::neutral] - PWM[droneControlType::roll][dronePWM::min];
	PWM[droneControlType::roll][dronePWM::neu2max] = PWM[droneControlType::roll][dronePWM::max] - PWM[droneControlType::roll][dronePWM::neutral];

	PWM[droneControlType::yaw][dronePWM::min2neu] = PWM[droneControlType::yaw][dronePWM::neutral] - PWM[droneControlType::yaw][dronePWM::min];
	PWM[droneControlType::yaw][dronePWM::neu2max] = PWM[droneControlType::yaw][dronePWM::max] - PWM[droneControlType::yaw][dronePWM::neutral];

}

void droneController::set_throttle(float percent)
{
	if (!is_permit) { return; }

	lock_guard<mutex> lock(mutex_throttle);
	PWM[droneControlType::throttle][dronePWM::current] = map(percent,droneControlType::throttle);
	
}
void droneController::set_pitch(float percent)
{
	if (!is_permit) { return; }
	lock_guard<mutex> lock(mutex_throttle);
	PWM[droneControlType::pitch][dronePWM::current] = map(percent, droneControlType::pitch);
}
void droneController::set_roll(float percent)
{
	if (!is_permit) { return; }
	lock_guard<mutex> lock(mutex_throttle);
	PWM[droneControlType::roll][dronePWM::current] = map(percent, droneControlType::roll);
}
void droneController::set_yaw(float percent)
{
	if (!is_permit) { return; }
	lock_guard<mutex> lock(mutex_throttle);
	PWM[droneControlType::yaw][dronePWM::current] = map(percent, droneControlType::yaw);
}

void droneController::set_throttle_fluctuation(float rate_of_change)
{
	if (!is_permit) { return; }
	set_throttle(get_pwm_percentage(droneControlType::throttle) + rate_of_change);
}

void droneController::set_pitch_fluctuation(float rate_of_change)
{
	if (!is_permit) { return; }
	set_throttle(get_pwm_percentage(droneControlType::pitch) + rate_of_change);
}

void droneController::set_roll_fluctuation(float rate_of_change)
{
	if (!is_permit) { return; }
	set_throttle(get_pwm_percentage(droneControlType::roll) + rate_of_change);
}

void droneController::set_yaw_fluctuation(float rate_of_change)
{
	if (!is_permit) { return; }
	set_throttle(get_pwm_percentage(droneControlType::yaw) + rate_of_change);
}

float droneController::get_pwm_percentage(droneControlType::Enum controlType)
{
	return this->pwm_percentage[controlType];
}

short droneController::get_pwm(droneControlType::Enum controlType)
{
	return this->PWM[controlType][dronePWM::current];
} 
string droneController::get_pwm_string() {
	string temp="#";
	temp+=std::to_string(PWM[droneControlType::throttle][dronePWM::current]);
	temp+=std::to_string(PWM[droneControlType::pitch][dronePWM::current]);
	temp+=std::to_string(PWM[droneControlType::roll][dronePWM::current]);
	temp+=std::to_string(PWM[droneControlType::yaw][dronePWM::current]);
	
	return temp;
}


double droneController::constrain(double percent)
{
	if (percent > 100) return 100.0;
	else if (percent < 0) return 0.0;
	return percent;
}

short droneController::map(float percent, droneControlType::Enum controlType)
{
	percent = constrain(percent);
	pwm_percentage[controlType] = percent;
	percent /= 100;
	switch(controlType){
	case droneControlType::throttle:
		//cout << PWM[controlType][dronePWM::min] + PWM[controlType][dronePWM::neu2max] * percent << endl;
			return PWM[controlType][dronePWM::min] + PWM[controlType][dronePWM::neu2max] * percent;
		break;
	default:
		if (percent == 50) {
			return PWM[controlType][dronePWM::neutral];
		}
		else if (percent < 50) {
			return PWM[controlType][dronePWM::min] + PWM[controlType][dronePWM::min2neu] * percent;
		}
		else if (percent > 50) {
			percent -= 50;
			return PWM[controlType][dronePWM::neutral] + PWM[controlType][dronePWM::neu2max] * percent;
		}
	}
	
}

void droneController::start()
{
	PWM[droneControlType::throttle][dronePWM::current] = PWM[droneControlType::throttle][dronePWM::min];
	PWM[droneControlType::yaw][dronePWM::current] = PWM[droneControlType::yaw][dronePWM::neutral];
	delayMicroseconds(1000);
	PWM[droneControlType::throttle][dronePWM::current] = PWM[droneControlType::throttle][dronePWM::min];
	PWM[droneControlType::yaw][dronePWM::current] = PWM[droneControlType::yaw][dronePWM::max];
	delay(4000);
	PWM[droneControlType::throttle][dronePWM::current] = PWM[droneControlType::throttle][dronePWM::min];
	PWM[droneControlType::yaw][dronePWM::current] = PWM[droneControlType::yaw][dronePWM::neutral];
	is_permit = true;
}

void droneController::stop_drone()
{
	is_permit = false;
	PWM[droneControlType::throttle][dronePWM::current] = PWM[droneControlType::throttle][dronePWM::min];
	PWM[droneControlType::pitch][dronePWM::current] = PWM[droneControlType::pitch][dronePWM::neutral];
	PWM[droneControlType::roll][dronePWM::current] = PWM[droneControlType::roll][dronePWM::neutral];
	PWM[droneControlType::yaw][dronePWM::current] = PWM[droneControlType::yaw][dronePWM::neutral];
	
	pwm_percentage[droneControlType::throttle] = 0;
	pwm_percentage[droneControlType::pitch] = 50;
	pwm_percentage[droneControlType::roll] = 50;
	pwm_percentage[droneControlType::yaw] = 50;
}