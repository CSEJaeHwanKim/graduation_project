#include "toNlanding.h"

#include <iostream>

#define LANDING_DEBUG_MODE1


toNlanding::toNlanding()
{
	is_working = false;
	setPoint = 5;
	_1st_pid = new PID(0.07, 0, 0, -2, 2, 0.001);	// p값을 줄이자
	_2nd_pid = new PID(0.06, 0, 0, -1, 1, 0.001);	// p값을 줄이자
	controller = droneController::getInstance();
	ultrasonic = UltrasonicClass::getInstance();
}

void toNlanding::set_altitude(float set_point)
{
	this->setPoint = set_point;
}

void toNlanding::start() {
	if (!this->is_working) {
		thread tt([&]() { calculate(); });
		tt.detach();
	}
}
void toNlanding::stop() {
	is_working=false;
}


void toNlanding::calculate() {

	try
	{
		is_working = true;
		while (is_working) {
			float distance = ultrasonic->getDistance();
			float velocity = ultrasonic->getVelocity();
			double _1st_result = _1st_pid->calculate(this->setPoint,distance);
			double output = _2nd_pid->calculate(_1st_result, velocity);
#ifdef LANDING_DEBUG_MODE
			cout << "distance : " << distance << " velocity : " << velocity << endl;
			cout << "_1st_result : " << _1st_result << " output : " << output << endl;
#endif
			controller->set_throttle_fluctuation((float)output);
			delayMicroseconds(1000);
		}

	}
	catch (const std::exception&)
	{
		is_working = false;
	}
}