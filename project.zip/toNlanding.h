#ifndef TONLANDING_H
#define TONLANDING_H

#include <thread>
#include <wiringPi.h>
#include "ultrasonic.h"
#include "singleton.hpp"
#include "pid.h"
#include "droneController.h"

class toNlanding : public singleton<toNlanding>
{
private :
	PID *_1st_pid, *_2nd_pid;
	droneController *controller;
	UltrasonicClass *ultrasonic;
private:
	unsigned char setPoint; // cm max 250;
	bool is_working;

public:
	toNlanding();
	void set_altitude(float set_point);
public :
	void start();
	void stop();
	void calculate();



};



#endif