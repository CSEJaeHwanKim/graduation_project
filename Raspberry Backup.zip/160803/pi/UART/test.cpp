#include <iostream>
#include <stdio.h> //for printf
#include <stdint.h>	//uint8_t definitions
#include <stdlib.h> //for exit(int);
#include <string> //for errno
#include <string.h>
#include <errno.h> //error output
 
 
//wiring Pi
#include <wiringPi.h>
#include <wiringSerial.h>
int main(void) {
	long _time = millis();
	long a = 0;
	while(true){
		printf("%d\n", a++);
		  if(millis()-_time>=30) {

			_time=millis();
		  }
	}
}