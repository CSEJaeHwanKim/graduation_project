/*
 Pi_Serial_test.cpp - SerialProtocol library - demo
 Copyright (c) 2014 NicoHood.  All right reserved.
 Program to test serial communication
 
 Compile with:
 sudo gcc -o Pi_Serial_Test.o Pi_Serial_Test.cpp -lwiringPi -DRaspberryPi -pedantic -Wall
 sudo ./Pi_Serial_Test.o
 */
 
// just that the Arduino IDE doesnt compile these files.
#ifdef RaspberryPi 
 //include system librarys
 
#include <iostream>
#include <stdio.h> //for printf
#include <stdint.h>	//uint8_t definitions
#include <stdlib.h> //for exit(int);
#include <string> //for errno
#include <string.h>
#include <errno.h> //error output
 
 
//wiring Pi
#include <wiringPi.h>
#include <wiringSerial.h>

#define LENGTH(a) sizeof(a)/sizeof(a[0])
 
using namespace std;
// Find Serial device on Raspberry with ~ls /dev/tty*
// ARDUINO_UNO "/dev/ttyACM0"
// FTDI_PROGRAMMER "/dev/ttyUSB0"
// HARDWARE_UART "/dev/ttyAMA0"
char device[]= "/dev/ttyACM0";
// filedescriptor
int fd;
unsigned long baud = 9600;
unsigned long _time = 0;

string str="";
 
string* strSplit(string strTarget, string strTok)
{
    int     nCutPos;
    int     nIndex     = 0;
    string* strResult = new string[100];
 
    while ((nCutPos = strTarget.find_first_of(strTok)) != strTarget.npos)
    {
        if (nCutPos > 0)
        {
            strResult[nIndex++] = strTarget.substr(0, nCutPos);
        }
        strTarget = strTarget.substr(nCutPos+1);
    }
 
    if(strTarget.length() > 0)
    {
        strResult[nIndex++] = strTarget.substr(0, nCutPos);
    }
 
    return strResult;
}


void setup(){
  printf("%s \n", "Raspberry Startup!");
  fflush(stdout);
 
  //get filedescriptor
  if ((fd = serialOpen (device, baud)) < 0) {
    fprintf (stderr, "Unable to open serial device: %s\n", strerror (errno)) ;
    exit(1); //error
  }
  
  //setup GPIO in wiringPi mode
  if (wiringPiSetup () == -1) {
    fprintf (stdout, "Unable to start wiringPi: %s\n", strerror (errno)) ;
    exit(1); //error
  }
}
 
void loop(){
  // Pong every 3 seconds
  if(millis()-_time>=3000) {
    serialPuts (fd, "Pong!\n");
    // you can also write data from 0-255
    // 65 is in ASCII 'A'
    serialPutchar (fd, 65);
    _time=millis();
  }
 	
  // read signal
  if(serialDataAvail (fd)) {
	char newChar = serialGetchar(fd);
	
	string *token;
	string *GPS;
	string *hpa; // 기압
	string *tmp;	// 온도
	string *altitude; // 고도
	// XBee
	string *nodeID;
	string *sensor_tmp;
	string *humid;
	string *RSSI;
	
	
	str += newChar;
		
	if( newChar == '@' ) {
		//cout << str << endl;
		token = strSplit(str, "@");
	
		string temp = *token;

		hpa = (strSplit(temp, "#") + 0);
		tmp = (strSplit(temp, "#") + 1);
		altitude = (strSplit(temp, "#") + 2);
		nodeID = (strSplit(temp, "#") + 3);
		sensor_tmp = (strSplit(temp, "#") + 4);
		humid = (strSplit(temp, "#") + 5);
		RSSI = (strSplit(temp, "#") + 6);
		
		cout << "hpa:: " << *hpa << endl;
		cout << "temperature:: " << *tmp << endl;
		cout << "altitude:: " << *altitude << endl;
		cout << "nodeID:: " << *nodeID << endl;
		cout << "sensor_temperature:: " << *sensor_tmp << endl;
		cout << "humidity:: " << *humid << endl;
		cout << "RSSI:: " << *RSSI << endl;
		
		str = "";
		serialFlush( fd );
	}
	
	//tcflush (fd, TCIOFLUSH);
    fflush(stdout);
  } 
}
 
// main function for normal c++ programs on Raspberry
int main(){
  setup();
  while(1)  {
	  loop();
  }
  return 0;
}
 
#endif //#ifdef RaspberryPi
