/***********************************************************************
 * SPICommMain.cpp. Sample program that tests the SPIComm class.
 * an SPIComm class object (rpi) is created. the rpi object is instantiated
 * using the overloaded constructor. which opens the spidev0.0 device with
 * SPI_MODE_0 (MODE 0) (defined in linux/spi/spidev.h), speed = 1MHz &
 * bitsPerWord=8.
 *
 * call the spiWriteRead function on the rpi object 20 times. Each time make sure
 * that conversion is configured for single ended conversion on CH0
 * i.e. transmit ->  byte1 = 0b00000001 (start bit)
 *                   byte2 = 0b1000000  (SGL/DIF = 1, D2=D1=D0=0)
 *                   byte3 = 0b00000000  (Don't care)
 *      receive  ->  byte1 = junk
 *                   byte2 = junk + b8 + b9
 *                   byte3 = b7 - b0
 *    
 * after conversion must merge data[1] and data[2] to get final result
 *
 *
 *
 * *********************************************************************/
#include "SPIComm.h"


int main(void)
{
    SPIComm rpi("/dev/spidev0.0", SPI_MODE_0, 1000000, 8);
    int i = 20;
    int SPIRxVal = 0;
    int SPIChannel = 0;
    unsigned char data[1];

    while(i > 0)
    {
        data[0] = i;  //  first byte transmitted
        rpi.spiWriteRead(data, sizeof(data) );
 
        SPIRxVal = data[0];
        sleep(1);
        //cout << "The Result is: " << SPIRxVal << endl;
        i--;
    }
    return 0;
}
