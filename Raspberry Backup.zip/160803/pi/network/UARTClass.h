#ifndef UART_H
#define UART_H
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

//wiring Pi
#include <wiringPi.h>
#include <wiringSerial.h>

using namespace std;

class UARTClass  {
	private :
		char *device;
		string str;
		int fd;	
		unsigned long baud;
		unsigned long m_time;
		char message[1024];
		bool is_ready;	

	public :
		UARTClass();
		// UARTClass( char device[], unsigned long baud, unsigned long time );
		virtual ~UARTClass();		
		string *strSplit( string strTarget, string strTok );
		void setup();
		void SendSerial( string msg );
		void loop(); // getMessage from Arduino
		void startCommunicate();
		
		char* getMsg();
		void setReady( bool TorF );
		bool getReady();
		void clearMsg();
};

#endif        /* UART_H */