#include "UARTClass.h"	
#include "ServerSocket.h"
#include "ClientSocket.h"
#include "SocketException.h"
//#include "UltrasonicClass.h"
#include <iostream>
#include <string>
#include <thread>

using namespace std;

// UART DATA To Raspberry 
// Raspberry To Web
void SendToWeb() {
	cout << "SendToWeb(1)" << endl;
	
	try {
		ClientSocket client( "218.150.181.154", 8800 );
		//UARTClass uart; 
		//uart.setup();
	
		cout << "SendToWeb(2)" << endl;
		//cout << uart.getReady() << endl;
		try {
			while( true ) {
				//cout << uart.getReady() << endl;
				//uart.startCommunicate();
				//cout << uart.getReady() << endl;
				//if( uart.getReady() ) {
					client << "Reply";
					//uart.setReady( false );
					//uart.clearMsg();
				//}
			}
		}
		catch ( SocketException& e ) {
			cout << "Exception was caught:" << e.description() << "\nExiting.\n";
		}
	} 
	catch ( SocketException& e ) {
      std::cout << "Exception was caught: ClientSocket" << e.description() << "\n";
    }

}

// Receive ORDER From Web
// T,Y,P,R DATA To Arduino
void RecvFromWeb() {
	string str;
	// UARTClass uart; 

	cout << "RecvFromWeb(1)" << endl;
	try {
		ServerSocket server( 5000 );	// Create the socket
		cout << "RecvFromWeb(2)" << endl;
		while ( true ) {
			cout << "RecvFromWeb(3)" << endl;
			ServerSocket new_sock;
			server.accept( new_sock );
			try {
				cout << "RecvFromWeb(4)" << endl;
				new_sock >> str;
			}
			catch ( SocketException& ) {}
		}
	}
	catch ( SocketException& e ) {
		cout << "Exception was caught: ServerSocket" << e.description() << "\nExiting.\n";
	}
}

int main() {
	//UltrasonicClass *sonic = UltrasonicClass::getInstance();
	//sonic->start();

	//thread clientTh( SendToWeb );
	thread clientTh([&]() { SendToWeb(); });
	//thread clientTh( RecvFromWeb );
	thread serverTh([&]() { RecvFromWeb(); });
	clientTh.detach();
	serverTh.detach();

	return 0;
}