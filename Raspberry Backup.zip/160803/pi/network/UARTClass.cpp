#include "UARTClass.h"
#include <thread>

UARTClass::UARTClass() {
	this->is_ready = false;
	this->str = "";
	
	strcpy( this->device, "/dev/ttyACM0");
	this->baud = 9600;
	this->m_time = 0;
}

UARTClass::~UARTClass() { }

string* UARTClass::strSplit(string strTarget, string strTok) {
	
    int     nCutPos;
    int     nIndex     = 0;
    string* strResult = new string[100];
 
    while ((nCutPos = strTarget.find_first_of(strTok)) != strTarget.npos)
    {
        if (nCutPos > 0)
        {
            strResult[nIndex++] = strTarget.substr( 0, nCutPos );
        }
        strTarget = strTarget.substr(nCutPos+1);
    }
 
    if(strTarget.length() > 0)
    {
        strResult[nIndex++] = strTarget.substr(0, nCutPos);
    }
 
    return strResult;
}

char * UARTClass::getMsg() {
	return this->message;
}

void UARTClass::setReady( bool TorF ) {
	this->is_ready = TorF;
}

bool UARTClass::getReady() {
	return this->is_ready;
}

void UARTClass::clearMsg() {
	int i;
	for( i=0;i<1024;i++ )
		this->message[i] = 0;
}

void UARTClass::setup() {
  printf("%s \n", "Raspberry Startup!");
  fflush(stdout);
 
  //get filedescriptor
  if ((fd = serialOpen (device, baud)) < 0) {
    fprintf (stderr, "Unable to open serial device: %s\n", strerror (errno));
    exit(1); //error
  }
  
  //setup GPIO in wiringPi mode
  if (wiringPiSetup () == -1) {
    fprintf (stdout, "Unable to start wiringPi: %s\n", strerror (errno)) ;
    exit(1); //error
  }
}

void UARTClass::SendSerial( string msg ) {
	serialPuts ( fd, msg.c_str() );
}

void UARTClass::loop() {
	// read signal from Arduino
	if(serialDataAvail (fd)) {
		char newChar = serialGetchar(fd);
		
		string *token;
		string *GPS;
		string *hpa; 		// 기압
		string *tmp;		// 온도
		string *altitude; 	// 고도
		// XBee
		string *nodeID;
		string *sensor_tmp;
		string *humid;
		string *RSSI;

		str += newChar;
		
		if( newChar == 'a' ) {
			cout << str << endl;
			strncpy(message, str.c_str(), sizeof(message));
			
			token = strSplit(str, "@");
			string temp = *token;

			//hpa = (strSplit(temp, "#") + 0);
			//tmp = (strSplit(temp, "#") + 1);
			//altitude = (strSplit(temp, "#") + 2);
			//nodeID = (strSplit(temp, "#") + 3);
			//sensor_tmp = (strSplit(temp, "#") + 4);
			//humid = (strSplit(temp, "#") + 5);
			//RSSI = (strSplit(temp, "#") + 6);
				
			str = "";
			serialFlush( fd );
			is_ready = true;
		}
		fflush(stdout);
	} 
}

void UARTClass::startCommunicate() {
	thread t([&]() {  loop(); }  );
	t.detach();
}