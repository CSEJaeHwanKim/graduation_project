#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> 
#include <string.h>
#include <string>
#include <stdint.h> //uint8_t definitions
#include <arpa/inet.h>
#include <sys/socket.h>
#include <pthread.h>
#include <errno.h> //error output

//wiring Pi
#include <wiringPi.h>
#include <wiringSerial.h>
	
#define BUF_SIZE 100
#define NAME_SIZE 20

using namespace std;

void * send_msg(void * arg);
void * handle_clnt(void * arg);

char message[1024];
bool is_ready = false;
bool isEnd = false;

string str="";
string strXBEE="";

char device[]= "/dev/ttyACM0";

// filedescriptor
int fd;
unsigned long baud = 9600;
unsigned long _time=0;

string* strSplit(string strTarget, string strTok) {
    int     nCutPos;
    int     nIndex     = 0;
    string* strResult = new string[100];
 
    while ((nCutPos = strTarget.find_first_of(strTok)) != strTarget.npos)
    {
        if (nCutPos > 0)
        {
            strResult[nIndex++] = strTarget.substr(0, nCutPos);
        }
        strTarget = strTarget.substr(nCutPos+1);
    }
 
    if(strTarget.length() > 0)
    {
        strResult[nIndex++] = strTarget.substr(0, nCutPos);
    }
 
    return strResult;
}

void setup(){
  printf("%s \n", "Raspberry Startup!");
  fflush(stdout);
 
  //get filedescriptor
  if ((fd = serialOpen (device, baud)) < 0){
    fprintf (stderr, "Unable to open serial device: %s\n", strerror (errno)) ;
    exit(1); //error
  }
  
  //setup GPIO in wiringPi mode
  if (wiringPiSetup () == -1){
    fprintf (stdout, "Unable to start wiringPi: %s\n", strerror (errno)) ;
    exit(1); //error
  }
}

void *loop( ) {
	//cout << "loopGps 1 " << endl;
	if(serialDataAvail (fd)) {
		char newChar = serialGetchar(fd);
		//cout << "loopGps 2 " << endl;
		/*string *token;
		string *GPS;
		string *hpa; 		// 기압
		string *tmp;		// 온도
		string *altitude; 	// 고도
		// XBee
		string *nodeID;
		string *sensor_tmp;
		string *humid;
		string *RSSI;
		*/
		if( !isEnd ) {
			str += newChar;
		}
		if( newChar == '+' ) {
			isEnd = false;
		}
		if( !isEnd && (newChar == 'a' ) ) {
			isEnd = true;
			str = str.substr(0, str.length()-1);
			str += "#";
		}
		
		if( newChar == 'x' ) {
			str = str.substr(0, str.length()-1);
			str += "#";
			cout << str << endl;
			strncpy(message, str.c_str(), sizeof(message));
			
			//token = strSplit(str, "g");
			//string temp = *token;

			//hpa = (strSplit(temp, "#") + 0);
			//tmp = (strSplit(temp, "#") + 1);
			//altitude = (strSplit(temp, "#") + 2);
			//nodeID = (strSplit(temp, "#") + 3);
			//sensor_tmp = (strSplit(temp, "#") + 4);
			//humid = (strSplit(temp, "#") + 5);
			//RSSI = (strSplit(temp, "#") + 6);
			
			//cout << "hpa:: " << *hpa << endl;
			//cout << "temperature:: " << *tmp << endl;
			//cout << "altitude:: " << *altitude << endl;
			//cout << "nodeID:: " << *nodeID << endl;
			//cout << "sensor_temperature:: " << *sensor_tmp << endl;
			//cout << "humidity:: " << *humid << endl;
			//cout << "RSSI:: " << *RSSI << endl;
			
			str = "";
			serialFlush( fd );
			is_ready = true;
			isEnd = false;
		}
		fflush(stdout);
  } 
}


int main(int argc, char *argv[])
{
	int sock, sock2, clnt_sock; // sock->client , sock2->server
	struct sockaddr_in serv_addr, serv_addr2, clnt_addr;
	
	void * thread_return;
	socklen_t  clnt_addr_sz;
	//변수 추가
	int str_len, option, option2;
	socklen_t optlen, optlen2;
	
	pthread_t snd_thread, rcv_thread; // thread 변수
	
	setup();

	/* create socket */
	sock = socket(PF_INET, SOCK_STREAM, 0); // write to Web		< CLIENT >
    sock2 = socket(PF_INET, SOCK_STREAM, 0);// read  from web  	< SERVER >

	// setsockopt option..
	optlen = sizeof(option);
	option = 1;
	setsockopt(sock2, SOL_SOCKET, SO_REUSEADDR, (void*)&option,optlen);

	/* for bind */
	// client
	memset(&serv_addr, 0, sizeof(serv_addr));
	serv_addr.sin_family=AF_INET;
	serv_addr.sin_addr.s_addr=inet_addr("218.150.181.154");
	serv_addr.sin_port=htons(5000);
	
	// server
    memset(&serv_addr2, 0, sizeof(serv_addr2));
    serv_addr2.sin_family=AF_INET;
    serv_addr2.sin_addr.s_addr=htonl(INADDR_ANY);
    serv_addr2.sin_port=htons(8800);
	
	/* */
	// client
	if( connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr))==-1 )
		cout << "connect() error" << endl;

	// server(bind, listen) 
	if( bind(sock2, (struct sockaddr*) &serv_addr2, sizeof(serv_addr2))==-1 ) 
		cout << "bind() error" << endl;

	if( listen(sock2, 5) == -1 )
		cout << "listen() error" << endl;
		
	// client 
	pthread_create(&snd_thread, NULL, send_msg, (void*)&sock);

	// 웹으로부터 오는 데이터 받기 
	while( true ) {
		clnt_addr_sz = sizeof(clnt_addr);
		clnt_sock = accept(sock2, (struct sockaddr*)&clnt_addr, &clnt_addr_sz);
		
		pthread_create(&rcv_thread, NULL, handle_clnt, (void*)&clnt_sock);
		
		//cout << "detach return value - > " << pthread_detach(rcv_thread) << endl;
		//cout << "Connected Client IP: " << inet_ntoa(clnt_addr.sin_addr) << endl;
	}

	close(sock);
	close(sock2); 
	return 0;
}
	

/* socket programming methods */
void * send_msg(void * arg)   // send thread main
{
	int sock=*((int*)arg);
	pthread_t xbeeTh, gpsTh; // thread 변수
	
	while( true ) {
		loop();
		if( is_ready ) {
			write(sock, message, strlen(message));
			is_ready = false;
			for(int i=0;i<1024;i++)
				message[i]=0;
		}
	}
	return NULL;
}
	
void * handle_clnt(void * arg)  { // read thread main (Drone ID)
    int clnt_sock = *( (int*) arg);
	int str_len;
	char id_msg[50];
	int i = 0;
	
	while( (str_len = read(clnt_sock, id_msg, sizeof(id_msg))) != 0 ) {
		write(clnt_sock, id_msg, str_len);
		id_msg[str_len] = i = 0;
		
		while( id_msg[i] != 0 )
			cout << id_msg[i++];
		printf("\n");
	}
	
	close(clnt_sock);
	return NULL;
}