#include "UARTClass.h"
#include <thread>

UARTClass::UARTClass() {
	this->is_end = false;
	this->is_ready = false;
	this->recvStr = "";
	
	device = "/dev/ttyACM0";
	this->baud = 9600;
	this->m_time = 0;
	this->fd = 0;
	for(int i=0;i<1024;i++ )
		this->message[i] = 0;
}

UARTClass::~UARTClass() {}

char* UARTClass::getMsg() {
	return this->message;
}

void UARTClass::setReady( bool TorF ) {
	this->is_ready = TorF;
}

bool UARTClass::getReady() {
	return this->is_ready;
}

void UARTClass::clearMsg() {
	int i;
	for( i=0;i<1024;i++ )
		this->message[i] = 0;
}

string* UARTClass::strSplit(string strTarget, string strTok) {
    int     nCutPos;
    int     nIndex     = 0;
    string* strResult = new string[100];
 
    while ((nCutPos = strTarget.find_first_of(strTok)) != strTarget.npos)
    {
        if (nCutPos > 0)
        {
            strResult[nIndex++] = strTarget.substr( 0, nCutPos );
        }
        strTarget = strTarget.substr(nCutPos+1);
    }
 
    if(strTarget.length() > 0)
    {
        strResult[nIndex++] = strTarget.substr(0, nCutPos);
    }
 
    return strResult;
}


void UARTClass::setup() {
  printf("%s \n", "Raspberry Startup!");
  fflush(stdout);
 
  //get filedescriptor
  if ((fd = serialOpen (device.c_str(), baud)) < 0) {
    fprintf (stderr, "Unable to open serial device: %s\n", strerror (errno));
    exit(1); //error
  }
  
  //setup GPIO in wiringPi mode
  if (wiringPiSetup () == -1) {
    fprintf (stdout, "Unable to start wiringPi: %s\n", strerror (errno)) ;
    exit(1); //error
  }
}

// send Message
void UARTClass::SendSerial( string msg ) {
	serialPuts ( fd, msg.c_str() );
}

// get Message
void UARTClass::loop() {
	// read signal from Arduino
	if(serialDataAvail (fd)) {
		char newChar = serialGetchar(fd);
		
		if( newChar == '{' ){
			is_end = true;
		}
		
		if( is_end ) {
			recvStr += newChar;
		}
		if( newChar == '}' ) {
			// Json
			cout << recvStr << endl;
			strncpy(message, recvStr.c_str(), sizeof(message));
			
			//bool parsingSuccessful = reader.parse(recvStr, root);
			//if( parsingSuccessful ) {
			//	cout << "Failed to parse configuration\n" << reader.getFormatedErrorMessages();
			//	exit(1);
			//}
			
			recvStr = "";
			serialFlush( fd );
			is_ready = true;
			is_end = false;
		}
		fflush(stdout);
	}
}

void UARTClass::startCommunicate() {
	thread t([&]() {  loop(); }  );
	t.detach();
}