#include "UARTClass.h"	
#include "ServerSocket.h"
#include "ClientSocket.h"
#include "SocketException.h"
//#include "UltrasonicClass.h"
//#include "AirpressClass.h"
//#include "GpsClass.h"
#include <iostream>
#include <string>
#include <thread>

// UART DATA To Raspberry 
// Raspberry To Web
void SendToWeb() {
	try {
		UARTClass uart; 
		uart.setup();
		ClientSocket client("218.150.181.154", 5000 );
		
		try {
			while( true ) {
				uart.startCommunicate();
				if( uart.getReady() ) {
					try {
						client << uart.getMsg();
						uart.setReady( false );
						uart.clearMsg();
					}
					catch( SocketException& e ) { 
						cout << e.description() << endl;
					}					
				}
			}
		}
		catch ( SocketException&e ) { cout << e.description() << endl; }
	}
	catch ( SocketException& e ) {
      cout << "Exception was caught: " << e.description() << "\n";
    }
}

// Receive ORDER From Web
// T,Y,P,R DATA To Arduino
void RecvFromWeb() {
	string str = "";
	// UARTClass uart; 

	try {
		ServerSocket server( 8800 );	// Create the socket
		while ( true ) {
			ServerSocket new_sock;
			server.accept( new_sock );
			try {	
				new_sock >> str;
				cout << str << endl;
				str = "";
			}
			catch ( SocketException &e) {
				cout << "Server Socket error : " << e.description() << endl;
			}
		}
	}
	catch ( SocketException& e ) {
		cout << "Exception was caught: " << e.description() << "\nExiting.\n";
	}
}

int main() {
	//GpsClass *gps = GpsClass::getInstance();
	//gps->start();
	
	//AirpressClass *airpress = AirpressClass::getInstance();
	//airpress->start();
	
	//UltrasonicClass *sonic = UltrasonicClass::getInstance();
	//sonic->start();
	
	thread serverTh([&]() { RecvFromWeb(); });
	serverTh.detach();
	thread clientTh([&]() { SendToWeb(); });
	clientTh.detach();
	
	while(1);

	return 0;
}