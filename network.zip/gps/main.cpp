#include <iostream>
#include <unistd.h>  

#include "gps.h"

int main() {
	gps *t = gps::getInstance();
	t->gps_on();
	
	while( true ) {
		cout << "Latitude = " <<  t->get_latitude() << endl;
		cout << "Longitude = " << t->get_longitude() << endl;
		cout << "Speed = " << t->get_speed() << endl;
		cout << "Altitude = " << t->get_altitude() << endl;
		cout << "Course = " << t->get_course() << "\n\n";
		usleep(100000);
	}
	
	return 1;
}