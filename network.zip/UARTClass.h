#ifndef UART_H
#define UART_H
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <errno.h>

//wiring Pi
#include <wiringPi.h>
#include <wiringSerial.h>

#include "json/json.h"
#include "json/reader.h"
#include "json/value.h"

using namespace std;
//using namespace Json;

class UARTClass  {
	private :
		string device;
		string recvStr;
		int fd;	
		unsigned long baud;
		unsigned long m_time;
		char message[1024];
		bool is_ready;	
		bool is_end;
		
		// Json
		//Json::Reader reader;
		//Json::Value root;

	public :
		UARTClass();
		virtual ~UARTClass();		
		string *strSplit( string strTarget, string strTok );
		void setup();
		void SendSerial( string msg );
		void loop(); // getMessage from Arduino
		void startCommunicate();
		
			
		char* getMsg();
		void setReady( bool TorF );
		bool getReady();
		void clearMsg();
};

#endif        /* UART_H */